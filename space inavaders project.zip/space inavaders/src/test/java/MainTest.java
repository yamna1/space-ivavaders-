import static org.junit.jupiter.api.Assertions.*;
import javax.swing.*;
import java.awt.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MainTest {

    private JFrame frame;

    @BeforeEach
    public void setUp() {
        // Initialize the frame before each test
        int tileSize = 32;
        int rows = 16;
        int columns = 16;
        int boardWidth = tileSize * columns;
        int boardHeight = tileSize * rows;

        frame = new JFrame("Space Invaders");
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        SpaceInvaders spaceInvaders = new SpaceInvaders();
        frame.add(spaceInvaders);
        frame.pack();
        spaceInvaders.requestFocus();
    }

    @Test
    public void testFrameInitialization() {
        // Test that the frame is properly initialized and is not null
        assertNotNull(frame, "Frame should not be null.");
        assertEquals("Space Invaders", frame.getTitle(), "Frame title should be 'Space Invaders'.");
        assertEquals(512, frame.getWidth(), "Frame width should be 512.");
        assertEquals(512, frame.getHeight(), "Frame height should be 512.");
    }

    @Test
    public void testFrameVisibility() {
        // Test if the frame is visible
        frame.setVisible(true);
        assertTrue(frame.isVisible(), "Frame should be visible.");
    }

    @Test
    public void testSpaceInvadersPanel() {
        // Verify that the SpaceInvaders panel is added to the frame
        Component[] components = frame.getContentPane().getComponents();
        boolean foundSpaceInvaders = false;
        for (Component component : components) {
            if (component instanceof SpaceInvaders) {
                foundSpaceInvaders = true;
                break;
            }
        }
        assertTrue(foundSpaceInvaders, "SpaceInvaders panel should be added to the frame.");
    }

    @Test
    public void testFrameNotResizable() {
        // Check that the frame is not resizable
        assertFalse(frame.isResizable(), "Frame should not be resizable.");
    }
}


