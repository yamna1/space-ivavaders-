import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import javax.swing.*;

public class SpaceInvaders extends JPanel implements ActionListener, KeyListener {
    class Block {
        int x, y, width, height;
        Image img;
        boolean alive = true;
        boolean used = false;

        Block(int x, int y, int width, int height, Image img) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.img = img;
        }
    }

    int tileSize = 32;
    int rows = 16;
    int columns = 16;
    int boardWidth = tileSize * columns;
    int boardHeight = tileSize * rows;
    int bestScore = 0;

    Image pink, cyan, yellow;
    Image ship;
    ArrayList<Image> alienImageArray; // Generics

    int shipWidth = tileSize * 2;
    int shipHeight = tileSize;
    int shipX = tileSize * columns / 2 - tileSize;
    int shipY = boardHeight - tileSize * 2;
    int shipVelocityX = tileSize;
    Block Ship;

    ArrayList<Block> alienArray; // Now a typed ArrayList<Block>.
    int alienWidth = tileSize * 2;
    int alienHeight = tileSize;
    int alienX = tileSize;
    int alienY = tileSize;

    int alienRows = 2;
    int alienColumns = 3;
    int alienCount = 0;
    int alienVelocityX = 2;

    ArrayList<Block> bulletArray; //Generics
    int bulletWidth = tileSize / 8;
    int bulletHeight = tileSize / 2;
    int bulletVelocityY = -10;

    Timer gameLoop;
    int score = 0;
    boolean gameOver = false;
    boolean showStartPage = true;
    boolean showGameOverPage =  false;
    Rectangle startButton;

    SpaceInvaders() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int mouseX = e.getX();
                int mouseY = e.getY();

                if (showStartPage) {
                    if (startButton.contains(mouseX, mouseY)) {
                        showStartPage = false;
                    }
                    requestFocus();
                } else if (showGameOverPage) {
                    if (startButton.contains(mouseX, mouseY)) { // Same button used for restart
                        restartGame();
                    }
                }
            }
        });

        try {
            ship = new ImageIcon(Objects.requireNonNull(getClass().getResource("/ship.png"))).getImage();
            cyan = new ImageIcon(Objects.requireNonNull(getClass().getResource("/cyan.png"))).getImage();
            pink = new ImageIcon(Objects.requireNonNull(getClass().getResource("/pink.png"))).getImage();
            yellow = new ImageIcon(Objects.requireNonNull(getClass().getResource("/yellow.png"))).getImage();
        } catch (Exception e) {
            System.err.println("Error loading images: " + e.getMessage());
            e.printStackTrace();
        }

        alienImageArray = new ArrayList<>();
        alienImageArray.add(cyan);
        alienImageArray.add(pink);
        alienImageArray.add(yellow);

        Ship = new Block(shipX, shipY, shipWidth, shipHeight, ship);
        alienArray = new ArrayList<>();
        bulletArray = new ArrayList<>();

        gameLoop = new Timer(1000 / 60, this);
        startButton = new Rectangle(boardWidth / 2 - 100, boardHeight / 2 - 30, 200, 60);
        createAliens();
        gameLoop.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (showStartPage) {
            drawStartPage(g);
        } else if (showGameOverPage) {
            drawGameOverPage(g);
        } else {
            draw(g);
        }
    }
    public void drawGameOverPage(Graphics g) {
        // Draw background with gradient for game over page
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(0, 0, Color.BLACK, boardWidth, boardHeight, Color.DARK_GRAY);
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, boardWidth, boardHeight);

        // Draw "Game Over" title
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 50));
        String gameOverMessage = "Game Over!";
        FontMetrics metrics = g.getFontMetrics();
        int x = (boardWidth - metrics.stringWidth(gameOverMessage)) / 2;
        int y = boardHeight / 3;
        g.drawString(gameOverMessage, x, y);

        // Draw current score message
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.PLAIN, 30));
        String scoreMessage = "Score: " + score;
        x = (boardWidth - metrics.stringWidth(scoreMessage)) / 2;
        y += 60;
        g.drawString(scoreMessage, x, y);

        // Draw best score message
        String bestScoreMessage = "Best Score: " + bestScore;
        x = (boardWidth - metrics.stringWidth(bestScoreMessage)) / 2;
        y += 40;
        g.drawString(bestScoreMessage, x, y);

        // Draw the restart button
        g.setColor(Color.GREEN);
        startButton = new Rectangle(boardWidth / 2 - 100, boardHeight / 2 + 100, 200, 60); // Adjust button position
        g.fillRoundRect(startButton.x, startButton.y, startButton.width, startButton.height, 25, 25);

        // Draw restart button text
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        String restartText = "Restart";
        x = startButton.x + (startButton.width - g.getFontMetrics().stringWidth(restartText)) / 2;
        y = startButton.y + (startButton.height + g.getFontMetrics().getAscent()) / 2 - 5;
        g.drawString(restartText, x, y);
    }
    public void restartGame() {
        Ship.x = shipX;
        alienArray.clear();
        bulletArray.clear();
        score = 0;
        alienVelocityX = 2;
        alienColumns = 3;
        alienRows = 2;
        gameOver = false;
        showGameOverPage = false;
        createAliens();
        gameLoop.start();
    }


    public void drawGameOver(Graphics g) {
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 38));
        String gameOverMessage = "Game Over!";
        FontMetrics metrics = g.getFontMetrics();
        int x = (boardWidth - metrics.stringWidth(gameOverMessage)) / 2;
        int y = boardHeight / 2;
        g.drawString(gameOverMessage, x, y);

        String scoreMessage = "Final Score: " + score;
        x = (boardWidth - metrics.stringWidth(scoreMessage)) / 2;
        y += 60; // Position the final score message below "Game Over!"
        g.drawString(scoreMessage, x, y);
    }

    public void draw(Graphics g) {
        g.drawImage(Ship.img, Ship.x, Ship.y, Ship.width, Ship.height, null);

        for (Block alien : alienArray) {
            if (alien.alive) {
                g.drawImage(alien.img, alien.x, alien.y, alien.width, alien.height, null);
            }
        }

        g.setColor(Color.white);
        for (Block bullet : bulletArray) {
            if (!bullet.used) {
                g.fillRect(bullet.x, bullet.y, bulletWidth, bulletHeight);
            }
        }

        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.PLAIN, 20));
        g.drawString("Best Score: " + bestScore, 10, 70);
        g.drawString("Score: " + score, 10, 35);
    }

    public void move() {
        for (Block alien : alienArray) {
            if (alien.alive) {
                alien.x += alienVelocityX;
                if (alien.x + alien.width >= boardWidth || alien.x <= 0) {
                    alienVelocityX *= -1;
                    alien.x += alienVelocityX * 2;
                    for (Block a : alienArray) {
                        a.y += alienHeight;
                    }
                }
                if (alien.y >= Ship.y) {
                    gameOver = true;
                }
            }
        }

        for (Block bullet : bulletArray) {
            bullet.y += bulletVelocityY;
            for (Block alien : alienArray) {
                if (!bullet.used && alien.alive && detectCollision(bullet, alien)) {
                    bullet.used = true;
                    alien.alive = false;
                    alienCount--;
                    score += 100;
                }
            }
        }

        while (bulletArray.size() > 0 && (bulletArray.get(0).used || bulletArray.get(0).y < 0)) {
            bulletArray.remove(0);
        }

        if (alienCount == 0) {
            score += alienColumns * alienRows * 100;
            alienColumns = Math.min(alienColumns + 1, columns / 2 - 2);
            alienRows = Math.min(alienRows + 1, rows - 6);
            alienArray.clear();
            bulletArray.clear();
            alienVelocityX += alienVelocityX > 0 ? 1 : -1; // Increase speed
            createAliens();
        }
    }

    public void createAliens() {
        Random random = new Random();
        for (int r = 0; r < alienRows; r++) {
            for (int c = 0; c < alienColumns; c++) {
                int randomImgIndex = random.nextInt(alienImageArray.size());
                Block alien = new Block(
                        alienX + c * alienWidth,
                        alienY + r * alienHeight,
                        alienWidth,
                        alienHeight,
                        alienImageArray.get(randomImgIndex)
                );
                alienArray.add(alien);
            }
        }
        alienCount = alienArray.size();


        boolean testRunOnce=false;
        if (!testRunOnce) {
            testRunOnce = true;
            if (alienCount != alienRows * alienColumns) {
                System.err.println("Test Failed: Alien count mismatch! Expected " +
                        (alienRows * alienColumns) + " but found " + alienCount);
            } else {
                System.out.println("Test Passed: Correct alien count (" + alienCount + ")");
            }
        }
    }


    public boolean detectCollision(Block a, Block b) {
        try {
            return a.x < b.x + b.width &&
                    a.x + a.width > b.x &&
                    a.y < b.y + b.height &&
                    a.y + a.height > b.y;
        } catch (Exception e) {
            System.err.println("Error detecting collision: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public void drawStartPage(Graphics g) {
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(0, 0, Color.BLACK, boardWidth, boardHeight, Color.DARK_GRAY);
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, boardWidth, boardHeight);

        // Draw the game title with a clean, modern font
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 52));
        String title = "Space Invaders";
        FontMetrics fm = g.getFontMetrics();
        int titleX = (boardWidth - fm.stringWidth(title)) / 2;
        int titleY = boardHeight / 3;
        g.drawString(title, titleX, titleY);

        // Draw instructions
        g.setFont(new Font("SansSerif", Font.PLAIN, 20));
        String instructions = "Press 'Start' to begin your mission!";
        int instructionsX = (boardWidth - g.getFontMetrics().stringWidth(instructions)) / 2;
        int instructionsY = titleY + 50;
        g.drawString(instructions, instructionsX, instructionsY);

        // Adjust the start button's position to be lower
        int buttonOffsetY = 30; // Adjust this value to move the button further down
        startButton.y += buttonOffsetY; // Update the actual `startButton` rectangle position

        // Draw the start button
        g.setColor(Color.GREEN);
        g.fillRoundRect(startButton.x, startButton.y, startButton.width, startButton.height, 25, 25);

        // Draw button text
        g.setColor(Color.BLACK);
        g.setFont(new Font("SansSerif", Font.BOLD, 24));
        String buttonText = "Start";
        int buttonTextX = startButton.x + (startButton.width - g.getFontMetrics().stringWidth(buttonText)) / 2;
        int buttonTextY = startButton.y + (startButton.height + g.getFontMetrics().getAscent()) / 2 - 5;
        g.drawString(buttonText, buttonTextX, buttonTextY);

        // Optional: Add a subtle shadow effect for the button
        g.setColor(new Color(0, 0, 0, 50));
        g.drawRoundRect(startButton.x + 2, startButton.y + 2, startButton.width, startButton.height, 25, 25);
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        if (!showStartPage && !showGameOverPage) {
            move();
            repaint();
            if (gameOver) {
                showGameOverPage = true;
                if (score > bestScore) {
                    bestScore = score;
                }
                gameLoop.stop();
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (!showStartPage) {
            if (gameOver) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) { // Use Enter key to restart
                    Ship.x = shipX;
                    alienArray.clear();
                    bulletArray.clear();
                    score = 0;
                    alienVelocityX = 2;
                    alienColumns = 3;
                    alienRows = 2;
                    gameOver = false;
                    createAliens();
                    gameLoop.start();
                }
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT && Ship.x - shipVelocityX >= 0) {
                Ship.x -= shipVelocityX;
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && Ship.x + shipWidth + shipVelocityX <= boardWidth) {
                Ship.x += shipVelocityX;
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                Block bullet = new Block(Ship.x + shipWidth * 15 / 32, Ship.y, bulletWidth, bulletHeight, null);
                bulletArray.add(bullet);
            }
        }
    }

}

